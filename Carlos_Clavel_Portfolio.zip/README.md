# Carlos Clavel — Personal Portfolio

## GitHub Pages Setup

1. Create a new **public** GitHub repository, for example `carlos-portfolio`.
2. Upload `index.html` and `style.css` to the repository.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save.
7. GitHub will provide the live GitHub Pages URL.

## Before submitting

Replace the three project placeholders in `index.html` with your actual completed projects.
Replace each `#` project link with a working GitHub repository or live demo.

Also update the GitHub link in the Contact section from:
https://github.com/

to your actual GitHub profile.

Then test every navigation and project link before submitting.
